function obj = horzcat(varargin)
error('Horizontal concatenation of state objects is not permitted');
end