function veclen = length(objA)
veclen = sum(objA.length);
end